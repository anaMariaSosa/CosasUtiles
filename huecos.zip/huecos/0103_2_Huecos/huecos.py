from typing import Iterable, List, Dict, Optional, Tuple
import pandas as pd
import numpy as np

def load_csv_data_table(filepath, encoding="utf-8"):
    """
    Lee un archivo CSV y devuelve un DataFrame de pandas.

    Args:
        filepath (str): Ruta del archivo CSV a leer.
        encoding (str): Codificación del archivo CSV. Por defecto es 'utf-8'.

    Returns:
        pd.DataFrame or None: DataFrame con los datos del archivo CSV, o None si ocurre un error.

    Raises:
        pd.errors.ParserError: Si hay un error al parsear el archivo CSV.
        Exception: Para capturar cualquier otro error inesperado.
    """
    try:
        data_table = pd.read_csv(
            filepath, sep=";", dtype=str, keep_default_na=False, encoding=encoding
        )
        print(
            f"[INFO]   Leida tabla: {os.path.basename(filepath)}  -  {len(data_table)} filas"
        )
        return data_table
    except pd.errors.ParserError:
        print(
            f"[ERROR]   Error al parsear el archivo {filepath}. Verifica el formato del archivo."
        )
        return None
    except Exception as e:
        print(f"[ERROR]   Ocurrió un error inesperado: {e}")
        return None

rdcd_wk_table = load_csv_data_table(r'')
huecos_table = load_csv_data_table(r'')
inventario_table = load_csv_data_table(r'')
ac_inv_ent_table = load_csv_data_table(r'')
    
df_rdcd_sem = pd.read_excel(r'')
df_huecos = pd.read_excel(r'')
df_inventario = pd.read_excel(r'')
df_inv_ent_ac = pd.read_excel(r'')

def eliminar_columnas(df: pd.DataFrame, columnas: Iterable[str], errores: str = "ignore") -> pd.DataFrame:
    """
    errores: "ignore" no falla si no existe la columna; "raise" para forzar error.
    """
    df = df.copy()
    return df.drop(columns=list(columnas), errors=errores)

def construir_columna(df: pd.DataFrame, columnas: Iterable[str], nombre_col: str, separador: str) -> pd.DataFrame:
    """
    Crea un Columna concatenando otras columnas como strings (tras trim). NaN -> "".
    """
    df = df.copy()
    cols = [c for c in columnas]
    piezas = []
    for c in cols:
        piezas.append(df[c].astype(str).fillna("").str.strip())
    df[nombre_col] = piezas[0]
    for p in piezas[1:]:
        df[nombre_col] = df[nombre_col] + separador + p
    return df

def es_vacio (valor) -> bool:
    if pd.isna(valor):
        return True
    if isinstance(valor,str) and valor.strip() == '':
        return True
    return False

def añade_col_condicional(
    df: pd.DataFrame,
    nombre_columna: str,
    condicion: str,
    valor_si: any,
    valor_no: any
) -> pd.DataFrame:
    """
    Añade una nueva columna con valores definidos por una condición.

    Parámetros:
    -----------
    df : pd.DataFrame
        DataFrame original.
    nombre_columna : str
        Nombre de la columna nueva.
    condicion : str
        Condición a evaluar sobre df (debe devolver una Serie booleana).
        Ejemplo: "df['f inst'].isna()"
    valor_si : any
        Valor asignado si la condición se cumple (True).
    valor_no : any
        Valor asignado si la condición no se cumple (False).

    Retorna:
    --------
    DataFrame con la nueva columna añadida.
    """
    df = df.copy()
    try:
        mask = eval(condicion, {"np": np, "pd": pd, "df": df,"es_vacio": es_vacio})
        if not isinstance(mask, (pd.Series, np.ndarray, list)):
            raise ValueError("La condición debe devolver una serie booleana.")
        df[nombre_columna] = np.where(mask, valor_si, valor_no)
    except Exception as e:
        raise ValueError(f"Error al evaluar la condición: {e}")
    return df

###################################

def comparar_tablas(
    df_left: pd.DataFrame,
    df_right: pd.DataFrame,
    keys: List[str],
    include_left: Optional[Iterable[str]] = None,
    include_right: Optional[Iterable[str]] = None,
    left_name: str = "left",
    right_name: str = "right",
    # ¿qué columnas comparar para decidir OK/DISCREPANCIA?
    compare_on: Optional[Iterable[str]] = None,  # por nombre base (sin sufijo). Si None => intersección de incluidas
    # normalización de texto antes de comparar
    normalize_text_on: Optional[Iterable[str]] = None,  # por nombre base
    strip: bool = True,
    lower: bool = True,
    # tolerancia numérica
    atol: float = 0.0,
    rtol: float = 0.0,
) -> pd.DataFrame:
    """
    Compara df_left y df_right por 'keys' y devuelve:
      - keys (tal cual, una sola vez)
      - columnas seleccionadas de left con sufijo _{left_name}
      - columnas seleccionadas de right con sufijo _{right_name}
      - 'estado' y 'diferencias'

    Estados:
      - "OK"                       -> existe en ambos y no hay diferencias en compare_on
      - "DISCREPANCIA"             -> existe en ambos y hay diferencias
      - "Está en {left} pero no en {right}"
      - "Está en {right} pero no en {left}"
    """
    # Validar claves
    faltan_left = [k for k in keys if k not in df_left.columns]
    faltan_right = [k for k in keys if k not in df_right.columns]
    if faltan_left or faltan_right:
        raise ValueError(f"Claves ausentes. Left:{faltan_left}  Right:{faltan_right}")

    # Si no especifican columnas a incluir, tomamos todas las no-clave
    if include_left is None:
        include_left = [c for c in df_left.columns if c not in keys]
    else:
        include_left = [c for c in include_left if c in df_left.columns]

    if include_right is None:
        include_right = [c for c in df_right.columns if c not in keys]
    else:
        include_right = [c for c in include_right if c in df_right.columns]

    # Seleccionar y renombrar con sufijos
    left_sel = df_left[keys + list(include_left)].copy()
    right_sel = df_right[keys + list(include_right)].copy()

    left_ren = {c: f"{c}_{left_name}" for c in include_left}
    right_ren = {c: f"{c}_{right_name}" for c in include_right}

    left_sel = left_sel.rename(columns=left_ren)
    right_sel = right_sel.rename(columns=right_ren)

    # Outer merge para conservar todo
    merged = left_sel.merge(
        right_sel,
        on=keys,
        how="outer",
        indicator=True
    )

    # Determinar columnas base a comparar
    left_bases  = {c.rsplit(f"_{left_name}", 1)[0] for c in left_ren.values()}
    right_bases = {c.rsplit(f"_{right_name}", 1)[0] for c in right_ren.values()}
    if compare_on is None:
        compare_bases = sorted(list(left_bases & right_bases))
    else:
        compare_bases = [c for c in compare_on if (c in left_bases and c in right_bases)]

    # Normalización de texto previa (si procede) SOLO en las columnas incluidas
    if normalize_text_on:
        for base in normalize_text_on:
            col_l = f"{base}_{left_name}"
            col_r = f"{base}_{right_name}"
            if col_l in merged.columns:
                s = merged[col_l].astype("string")
                if strip: s = s.str.strip()
                if lower: s = s.str.lower()
                merged[col_l] = s
            if col_r in merged.columns:
                s = merged[col_r].astype("string")
                if strip: s = s.str.strip()
                if lower: s = s.str.lower()
                merged[col_r] = s

    # Helpers de comparación
    def iguales(v1, v2) -> bool:
        # NaN == NaN
        if pd.isna(v1) and pd.isna(v2):
            return True
        # Intentar numérico con tolerancia
        try:
            return np.isclose(float(v1), float(v2), atol=atol, rtol=rtol, equal_nan=True)
        except Exception:
            # Fallback: string comparado ya normalizado si tocaba
            return str(v1) == str(v2)

    # Construir estado + diferencias
    estados = []
    difs = []
    for _, row in merged.iterrows():
        where = row["_merge"]
        if where == "left_only":
            estados.append(f"Está en {left_name} pero no en {right_name}")
            difs.append([])
            continue
        if where == "right_only":
            estados.append(f"Está en {right_name} pero no en {left_name}")
            difs.append([])
            continue
        # En ambos: comparar compare_bases
        distintos = []
        for base in compare_bases:
            v1 = row.get(f"{base}_{left_name}", pd.NA)
            v2 = row.get(f"{base}_{right_name}", pd.NA)
            if not iguales(v1, v2):
                distintos.append(base)
        estados.append("OK" if not distintos else "DISCREPANCIA")
        difs.append(distintos)

    merged["estado"] = estados
    merged["diferencias"] = [", ".join(d) if d else "" for d in difs]

    # Orden de salida: keys + (left incluidas) + (right incluidas) + estado + diferencias
    out_cols = list(keys) + [f"{c}_{left_name}" for c in include_left] + [f"{c}_{right_name}" for c in include_right] + ["estado", "diferencias"]
    return merged[out_cols]

#######################################

df_clean_h=eliminar_columnas(huecos_table,[eliminar_columnas(huecos_table,["eq_i_lot_seri","ti_ubicaci","eq_f_cum_vida",
                                         "subeq_i_lot_seri","subeq_f_cum_vida",
                                         "eq_nom_edc_or","eq_nom_edc_es","ae_nom_edc_or",
                                         "ae_nom_edc_es","ae_de_c_posed","i_e_critic"
                                         ,"sag_i_e_critic","c_esencial","esencialidad",
                                         "tipo_potencial","tsn","t_dsd_vipo","vi_autoriz",
                                         "pct_tolera","pl_periodo","descripcio","cvalor1",
                                         "contenido_tablas_valor2","amp_vi_aut",
                                         "f_lim_ampl","factor","i_cum_indi","f_eve_orig"])])
df_clean_inv=eliminar_columnas(inventario_table,[eliminar_columnas(huecos_table,["eq_i_lot_seri","ti_ubicaci","eq_f_cum_vida",
                                         "subeq_i_lot_seri","subeq_f_cum_vida",
                                         "eq_nom_edc_or","eq_nom_edc_es","ae_nom_edc_or",
                                         "ae_nom_edc_es","ae_de_c_posed","i_e_critic"
                                         ,"sag_i_e_critic","c_esencial","esencialidad",
                                         "tipo_potencial","tsn","t_dsd_vipo","vi_autoriz",
                                         "pct_tolera","pl_periodo","descripcio","cvalor1",
                                         "contenido_tablas_valor2","amp_vi_aut",
                                         "f_lim_ampl","factor","i_cum_indi","f_eve_orig"])])

df_sin_dupes_h = df_clean_h.drop_duplicates(keep="first")
df_sin_dupes_inv = df_clean_inv.drop_duplicates(keep="first")

df_sin_dupes_con_ac_h = construir_columna(df_sin_dupes_h,columnas=["eq_c_sis_arma","eq_n_servicio"],nombre_col="AC",separador="-")
#ID real no el que use para calidad teniendo en cuenta tci, vidas, tms,etc sino el lcn-var-pos-pn-sn
df_sin_dupes_con_ac_h = construir_columna(df_sin_dupes_con_ac_h,columnas=["AC","eq_iec","eq_c_pos_edc","eq_pnr","eq_sn",
                                                                          "subeq_iec_mtr_eq","subeq_pnr","subeq_sn"
                                                                          ],nombre_col="ID",separador="")
df_sin_dupes_con_ac_conMDMD_h = añade_col_condicional(
    df_sin_dupes_con_ac_h,
    nombre_columna="M_D",
    condicion="df['eq_f_instalac'].apply(es_vacio) | df['subeq_f_instalac'].apply(es_vacio)",
    valor_si="D",   # D si está vacía
    valor_no="M"    # M si tiene fecha
)

df_sin_dupes_con_ac_inv = construir_columna(df_sin_dupes_inv,columnas=["s ar","cola"],nombre_col="AC",separador="-")
df_sin_dupes_con_ac_inv = construir_columna(df_sin_dupes_con_ac_inv,columnas=["AC","eq_iec","eq_var_edc","eq_c_pos_edc",
                                                                              "eq_pnr","eq_sn","subeq_var_edc_me","subeq_iec_mtr_eq",
                                                                              "subeq_pnr","subeq_sn"],nombre_col="ID",separador="")
df_sin_dupes_con_ac_conMDMD_inv = añade_col_condicional(
    df_sin_dupes_con_ac_inv,
    nombre_columna="M_D",
    condicion="~(df['eq_f_instalac'].apply(es_vacio))| (df['eq_f_instalac'].apply(es_vacio) & ~(df['subeq_f_instalac'].apply(es_vacio)))",
    valor_si="M",   # M si tiene fecha
    valor_no="D"    # D si está vacía
)

avion = df_sin_dupes_con_ac_conMDMD_h["AC"].iloc[0]
rdcd_wk_table_un_ac = rdcd_wk_table[rdcd_wk_table["rdcd_sem_n_cola"]==avion]
rdcd_wk_table_un_ac_id = construir_columna(rdcd_wk_table_un_ac,columnas=["rdcd_sem_n_cola","rdcd_sem_iec_eq","rdcd_sem_var_eq",
                                                                         "rdcd_sem_pos_eq","rdcd_sem_pn_eq",
                                                                         "rdcd_sem_sn_eq","rdcd_sem_var_comp",
                                                                         "rdcd_sem_iec_comp","rdcd_sem_pn_comp",
                                                                         "rdcd_sem_sn_comp"],nombre_col="ID",separador="")
rdcd_wk_table_un_ac_id = construir_columna(rdcd_wk_table_un_ac_id,columnas=["rdcd_sem_acc"],nombre_col="M_D",separador="")

#me tengo que quedar con el ultimo movimiento de cada ID en el semanal
#pero tendre que separar en comp y eq...
#rdcd_wk_table_un_ac_id_lastMD = rdcd_wk_table_un_ac_id.sor_values
# ("fehcaas de instalacion").drop_duplicates(subset=[todas las columnas menos M_D], 
# keep="last")
rdcd_wk_table_un_ac_id_lastMD = rdcd_wk_table_un_ac_id
#ojo el id del semanal no tien el ispa osea q ya lo filtra bien!! mira le metodo
#al unir h y inv hay duplicados (seran equipos) quitarlos

#quitar sn d elso id, ver si con los id mejora l acos asino continuar con unico id


claves = ["ID"]
col_h = ["AC","eq_iec","eq_var_edc","eq_c_pos_edc","eq_pnr",
         "eq_sn","subeq_var_edc_me","subeq_iec_mtr_eq","subeq_pnr",
          "subeq_sn","M_D"]
col_inv = ["AC","eq_iec","eq_var_edc","eq_c_pos_edc","eq_pnr",
         "eq_sn","subeq_var_edc_me","subeq_iec_mtr_eq","subeq_pnr",
          "subeq_sn","M_D"]
col_rdcd = ["rdcd_sem_n_cola","rdcd_sem_iec_eq","rdcd_sem_var_eq",
          "rdcd_sem_pos_eq","rdcd_sem_pn_eq",
          "rdcd_sem_sn_eq","rdcd_sem_var_comp",
           "rdcd_sem_iec_comp","rdcd_sem_pn_comp",
           "rdcd_sem_sn_comp","M_D"]

resultado_h_loquetieneRDCD = comparar_tablas(df_left=rdcd_wk_table_un_ac_id_lastMD,
                                             df_right=df_sin_dupes_con_ac_conMDMD_h, 
                                             keys=claves,include_left=col_rdcd,
                                             include_right=col_h, left_name="RDCD", 
                                             right_name="HUECOS",)
resultado_h_loquetieneHuecos = comparar_tablas(df_left=df_sin_dupes_con_ac_conMDMD_h,
                                               df_right=rdcd_wk_table_un_ac_id_lastMD, 
                                               keys=claves,include_right=col_rdcd,
                                               include_left=col_h, right_name="RDCD", 
                                               left_name="HUECOS",)
resultado_inv_loquetieneRDCD = comparar_tablas(df_left=rdcd_wk_table_un_ac_id,
                                               df_right=df_sin_dupes_con_ac_conMDMD_inv,
                                                 keys=claves, include_left=col_rdcd,
                                                 include_right=col_inv,left_name="RDCD",
                                                   right_name="INVENTARIO")
resultado_inv_loquetieneInv = comparar_tablas(df_right=rdcd_wk_table_un_ac_id,
                                              df_left=df_sin_dupes_con_ac_conMDMD_inv, 
                                              keys=claves, include_right=col_rdcd,
                                              include_left=col_inv,right_name="RDCD", 
                                              left_name="INVENTARIO")